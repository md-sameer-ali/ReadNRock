var swiper = new Swiper(".mySwiper", {
    slidesPerView: 10,
    spaceBetween: 7,

    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});